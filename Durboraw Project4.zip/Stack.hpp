/**************************************************************************
 * Name: Eric Durboraw
 * Date: 2/15/2017
 * File: Stack.hpp
 * Description: This is the header for the Stack class. It will have
 * the ability to add and remove the head or tail node, print the head or,
 * tail node and identify if the list is empty.
 * ***********************************************************************/

#ifndef STACK_HPP
#define STACK_HPP

#include <iostream>
#include <cstdlib>
#include "creature.hpp"

using std::cin;
using std::cout;
using std::endl;

class Stack
{
	protected:
		struct ListNode
		{
			creature* value;
			ListNode *next;
			ListNode(creature* value1, ListNode *next1 = NULL)
			{
				value = value1;
				next = next1;
			}
		};
		ListNode *head;
		ListNode *tail;

	public:
		Stack();
		~Stack();
		void addTail(creature* newCreat);
		void addFront(creature* newCreat);
		void removeFront();
		void removeTail();
		void printHead();
		void printTail();
		void displayList();
		bool Empty();
};
#endif

