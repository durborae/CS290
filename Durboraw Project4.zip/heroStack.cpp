/***********************************************************************
 * Name: Eric Durboraw
 * Date: 2/27/2017
 * File: heroStack.cpp
 * Description: This will implement the heroStack function with a 
 * constructor and destructor, addHero to add creatures to the alive
 * queue, death function to move them from alive to dead, and functions
 * to print the stack/queue.
 * *********************************************************************/

#include <iostream>
#include "heroStack.hpp"
#include "Queue.hpp"
#include "Stack.hpp"
#include "creature.hpp"
#include "barbarian.hpp"
#include "vampire.hpp"
#include "harrypotter.hpp"
#include "medusa.hpp"
#include "bluemen.hpp"

using std::cout;
using std::cin;
using std::endl;

/***********************************************************************
 * Function: heroStack::heroStack();
 * Description: This will just create a hero class object. The addHero
 * function will later be used populate the list
 * ********************************************************************/

heroStack::heroStack()
{
}

/***********************************************************************
 * Function: heroStack::~heroStack()
 * Description: This will create the default constructor
 * ********************************************************************/

heroStack::~heroStack()
{
}

/***********************************************************************
 * Function: heroStack::addHero(creature)
 * Description: This will add a hero to the list and incremement the 
 * aliveNum variable
 * ********************************************************************/

void heroStack::addHero(creature* uCreature)
{
	alive.addBack(uCreature);
	aliveNum++;
}

/***********************************************************************
 * Function: heroStack::death()
 * Description: This will move a creature from the alive queue to the 
 * dead stack.  It will decremement aliveNum and increment deadNum
 * ********************************************************************/

void heroStack::death()
{
	creature* transfer = alive.getFront();
	alive.removeFront();
	dead.addTail(transfer);
	aliveNum--;
	deadNum++;
}

/***********************************************************************
 * Function: printDead()
 * Description: This function will print the dead list.
 * ********************************************************************/

void heroStack::printDead()
{	
	if(!dead.Empty())
	{
		for(int counter = 0; counter < deadNum; counter++)
		{	
			cout << "RIP: ";
			dead.printTail();
//			cout << "here!!!!" << endl;
			dead.removeTail();
//			cout << "There" << endl;
		}
		cout << "I do not fear death. I had been dead for billions and billions of years before I was born, and had not suffered the slightest inconvenience from it.--Mark Twain" << endl; 
	}
	else
	{
		cout << "The list is empty" << endl;
	}	
}

/************************************************************************
 * Function: currentCreature()
 * Description: This function will return the creature at the front of the
 * alive container
 * *********************************************************************/

creature* heroStack::currentCreature()
{
	creature* transfer = alive.getFront();
	return transfer;
}

/*************************************************************************
 * Function: winner()
 * Description: This function will remove the front creature, call the
 * restore life function and return the creature to the back of the queue
 * **********************************************************************/

void heroStack::winner()
{
	creature* transfer = alive.getFront();
	transfer->restoreLife();
	alive.removeFront();
	this->addHero(transfer);
}
