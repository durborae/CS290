/*************************************************************************
 * Name: Eric Durboraw
 * Date: 2/11/2017
 * File: creature.cpp
 * Description: This will implement the creature class.  It just has a 
 * constructor, all other functions are virtual.
 * ***********************************************************************/

#include "creature.hpp"
#include <cstdlib>
#include <ctime>

creature::creature()
{
	totalLife =0;
	type = "Creature";
	sPoints = 0;
	armor = 0;
	attackDie = 6;
	defenseDie = 6;
}

//defining virtual functions

int creature::attack()
{
	return 0;
}

int creature::defense()
{
	return 0;
}

int creature::getSPoints()
{
	return 0;
}

void creature::setSPoints(int)
{
}

void creature::takeDamage(int)
{
}




void creature::operator=(const creature &right)
{
	type = right.type;
	sPoints = right.sPoints;
	armor = right.armor;
	attackDie = right.attackDie;
	defenseDie = right.defenseDie;
}

string creature::getType()
{
	return type;
}

void creature::restoreLife()
{
	int lifeRestore;

	lifeRestore = rand() % 5 + 1;
	lifeRestore += 10;

	sPoints *= 10;
	sPoints *= lifeRestore;
	sPoints /= 100;
	
	if(sPoints > totalLife)
	{
		sPoints = totalLife;
	}
}
