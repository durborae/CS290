/**************************************************************************
 * Name: Eric Durboraw
 * Date: 2/11/2017
 * File: vampire.cpp
 * Description: This file will implement the vampire class.  It will have
 * functions to attack, defend, get and set strength points, take damage
 * and a constructor.
 * ***********************************************************************/

#include "creature.hpp"
#include "vampire.hpp"
#include <iostream>
#include <cmath>
#include <ctime>
#include <cstdlib>
#include <string>

using std::cin;
using std::cout;
using std::endl;
using std::string;

/**************************************************************************
 * Function: vampire::vampire()
 * Description: This will create a vampire creature and assign values for
 * strength points, armor, attack and defense die and define the functions
 * set as "virtual" by the base class
 * ***********************************************************************/

vampire::vampire()
{
	totalLife = 18;
	type = "Vampire";
	numDie = 1;
	armor = 1;
	attackDie = 12;
	defenseDie = 6;
	sPoints = 18;
	cout << "Our competitor, the Vampire, hails from Transylvania and sparkles in the sun." << endl;
}

/**************************************************************************
 * Function: vampire::attack();
 * Description: This function will generate a number 1-12 to simulate a 
 * d12 roll
 * ***********************************************************************/

int vampire::attack()
{
	int attackRoll;

	attackRoll = rand() % attackDie + 1;

	return attackRoll;
}

/**************************************************************************
 * Function: vampire::defense()
 * Description: This function will generate a random number 1-6 to simulate
 * a d6 roll.  If the number > 3, it will set charmed to true
 * ***********************************************************************/

int vampire::defense()
{
	int defenseRoll;

	defenseRoll = rand() % defenseDie + 1;

	if(defenseRoll > 3)
	{
		charmed = true;
	}

	return defenseRoll;
}

/**************************************************************************
 * Function: vampire::getSPoints()
 * Description: This function will return the sPoints
 * ***********************************************************************/

int vampire::getSPoints()
{
	return sPoints;
}

/**************************************************************************
 * Function: vampire::setSPoints()
 * Description: This function will allow the setting the sPoints
 * ***********************************************************************/

void vampire::setSPoints(int sIn)
{
	sPoints = sIn;
}

/**************************************************************************
 * Function: vampire::takeDamage(int)
 * Description: This function will receive a damage parameter and call the
 * defense function and determine damage resolutionl. If charmed = true
 * it set the enemy damage to zero and mock the opponent.
 * ***********************************************************************/

void vampire::takeDamage(int oppDamage)
{
	int dRoll = this->defense();
	cout << "Vampire Defends for: " << dRoll << endl;
		
	int endDam;
	if(charmed == true)
	{
		oppDamage = 0;
		cout << "You are charmed! You must be Tom Cruisin for a Bruisin!" << endl;
		charmed = false;
	}
		
	endDam = oppDamage - dRoll - armor;
	//cout << "Damage Dif: " << endDam << endl;
	if(endDam > 0)
	{
		dRoll = sPoints - endDam;
		this->setSPoints(dRoll);
	}
}

string vampire::getType()
{
	return type;
}
