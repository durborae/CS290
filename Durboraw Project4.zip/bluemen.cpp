/*************************************************************************
 * Name: Eric Durboraw
 * Date: 2/12/2017
 * File: bluemen.cpp
 * Description: This file will implement the bluemen class.  It will have
 * functions to attack, defend, get and set strength points and resolve
 * damage.
 * ***********************************************************************/

#include "creature.hpp"
#include "bluemen.hpp"
#include <iostream>
#include <cmath>
#include <ctime>
#include <cstdlib>
#include <string>

using std::cin;
using std::cout;
using std::endl;
using std::string;

/**************************************************************************
 * Function: bluemen::bluemen()
 * Description: This will create a bluemen creature and assign values for
 * strength points, armor, attack and defense die and define the functions
 * set as "virtual" by the base class
 * ***********************************************************************/

bluemen::bluemen()
{
		totalLife = 12;
		type = "Bluemen";
		numDie = 2;
		armor = 3;
		attackDie = 10;
		defenseDie = 6;
		sPoints = 12;
		dDie = 3;
		cout << "Our competitor, the bluemen, hail from Las Vegas and are known for their work in Intel commercials." << endl;
}

/**************************************************************************
 * Function: bluemen::attack();
 * Description: This function will generate 2 numbers 1-10 to simulate two 
 * d10 rolls
 * ***********************************************************************/

int bluemen::attack()
{
		int attackRoll;
		int totalRoll = 0;
		for(int counter = 0; counter < numDie; counter++)
		{
				attackRoll = rand() % attackDie + 1;
				totalRoll += attackRoll;
		}
		return totalRoll;
}

/**************************************************************************
 * Function: bluemen::defense()
 * Description: This function will generate 2 random numbers 1-6 to simulate
 * 2 d6 rolls.  It will return the sum of those two rolls
 * ***********************************************************************/

int bluemen::defense()
{
		int defenseRoll;
		int DRoll = 0;
		for(int counter = 0; counter < dDie; counter++)
		{			
				defenseRoll = rand() % defenseDie + 1;
				DRoll += defenseRoll;
		}
		return DRoll;
}

/**************************************************************************
 * Function: bluemen::getSPoints()
 * Description: This function will return the sPoints
 * ***********************************************************************/

int bluemen::getSPoints()
{
		return sPoints;
}

/**************************************************************************
 * Function: bluemen::setSPoints()
 * Description: This function will allow the setting the sPoints
 * ***********************************************************************/

void bluemen::setSPoints(int sIn)
{
		sPoints = sIn;
}

/**************************************************************************
 * Function: bluemen::takeDamage(int)
 * Description: This function will receive a damage parameter and call the
 * defense function and determine damage resolutionl. 
 * ***********************************************************************/

void bluemen::takeDamage(int oppDamage)
{
		int dRoll = this->defense();
		cout << "Bluemen Defend for: " << dRoll << endl;
		int endDam;

		endDam = oppDamage - dRoll - armor;
		if(endDam > 0)
		{
				dRoll = sPoints - endDam;
				this->setSPoints(dRoll);
		}
		this->checkDDie();
}


/**************************************************************************
 * Function: bluemen::checkDDie()
 * Description: This function will check and adjust defensive dice based on
 * strenth points
 * ***********************************************************************/

void bluemen::checkDDie()
{
	if(sPoints <= 4)
	{
		dDie = 1;
		cout << "Defense Die Lost!" << endl;
	}
	else if(sPoints <= 8)
	{
		dDie = 2;
		cout << "Defense Die Lost!" << endl;
	}
}

string bluemen::getType()
{
	return type;
}
