/*************************************************************************
 * Name: Eric Durboraw
 * Date: 2/3/2017
 * File: menu.cpp
 * Description: This file will be the menu for the list function.
 * ***********************************************************************/

#include "menu.hpp"
#include "creature.hpp"
#include "barbarian.hpp"
#include "vampire.hpp"
#include "bluemen.hpp"
#include "medusa.hpp"
#include "harrypotter.hpp"
#include <iostream>
#include <string>
#include <ctime>
#include <cstdlib>
#include "battleground.hpp"
#include "heroStack.hpp"
#include "Queue.hpp"
#include "Stack.hpp"


using std::cin;
using std::cout;
using std::endl;
using std::string;

void menu()
{
	heroStack player1;
	heroStack player2;
	int choice = -1;
	bool p1 = false;
	bool p2 = true;
	creature* player11;
	creature* player12;
	creature* player13;
	creature* player21;
	creature* player22;
	creature* player23;
	int p1CreatNum = 0;
	int p2CreatNum = 0;



	cout << "Hi! Welcome to the BattleDome of Death!!!!!!!" << endl;
	while(choice != 6)
	{
		if(p1==false)
		{
			cout << "Player 1, please choose creature #" << p1CreatNum + 1 << endl;
		}
		else if(p2 == false)
		{
			cout << "Player 2, please choose creature #" << p2CreatNum + 1 << endl;
		}

		while((choice < 1 || choice > 6))
		{
			cout << "1. Barbarian" << endl;
			cout << "2. Bluemen" << endl;
			cout << "3. Harry Potter" << endl;
			cout << "4. Medusa" << endl;
			cout << "5. Vampire" << endl;
			cout << "6. End Program" << endl;
			cin >> choice;
		}

		switch (choice)
		{
			case 1:
				if(p1 == false && p1CreatNum == 0)
				{
					player11 = new barbarian;
					p1 = true;
					p2 = false;
					choice = -1;
					player1.addHero(player11);
					p1CreatNum++;
					break;
				}
				else if(p1 == false && p1CreatNum == 1)
				{
					player12 = new barbarian;
					p1 = true;
					p2 = false;
					choice = -1;
					player1.addHero(player12);
					p1CreatNum++;
					break;
				}
				else if(p1 == false && p1CreatNum == 2)
				{
					player13 = new barbarian;
					p1 = true;
					p2 = false;
					choice = -1;
					player1.addHero(player13);
					p1CreatNum++;
					break;
				}
				else if(p2 == false && p2CreatNum == 0)
				{
					player21 = new barbarian;
					p2 = true;
					p1 = false;
					choice = -1;
					player2.addHero(player21);
					p2CreatNum++;
					break;
				}
				else if(p2 == false && p2CreatNum == 1)
				{
					player22 = new barbarian;
					p2 = true;
					p1 = false;
					choice = -1;
					player2.addHero(player22);
					p2CreatNum++;
					break;
				}
				else if(p2 == false && p2CreatNum == 2)
				{
					player23 = new barbarian;
					p2 = true;
					p1 = false;
					choice = 6;
					player2.addHero(player23);
					p2CreatNum++;
					break;
				}
				break;

			case 2: //bluemen
				
				if(p1 == false && p1CreatNum == 0)
				{
					player11 = new bluemen;
					p1 = true;
					p2 = false;
					choice = -1;
					player1.addHero(player11);
					p1CreatNum++;
					break;
				}
				else if(p1 == false && p1CreatNum == 1)
				{
					player12 = new bluemen;
					p1 = true;
					p2 = false;
					choice = -1;
					player1.addHero(player12);
					p1CreatNum++;
					break;
				}
				else if(p1 == false && p1CreatNum == 2)
				{
					player13 = new bluemen;
					p1 = true;
					p2 = false;
					choice = -1;
					player1.addHero(player13);
					p1CreatNum++;
					break;
				}
				else if(p2 == false && p2CreatNum == 0)
				{
					player21 = new bluemen;
					p2 = true;
					p1 = false;
					choice = -1;
					player2.addHero(player21);
					p2CreatNum++;
					break;
				}
				else if(p2 == false && p2CreatNum == 1)
				{
					player22 = new bluemen;
					p2 = true;
					p1 = false;
					choice = -1;
					player2.addHero(player22);
					p2CreatNum++;
					break;
				}
				else if(p2 == false && p2CreatNum == 2)
				{
					player23 = new bluemen;
					p2 = true;
					p1 = false;
					choice = 6;
					player2.addHero(player23);
					p2CreatNum++;
					break;
				}
				break;

			case 3: //harrypotter
				if(p1 == false && p1CreatNum == 0)
				{
					player11 = new harrypotter;
					p1 = true;
					p2 = false;
					choice = -1;
					player1.addHero(player11);
					p1CreatNum++;
					break;
				}
				else if(p1 == false && p1CreatNum == 1)
				{
					player12 = new harrypotter;
					p1 = true;
					p2 = false;
					choice = -1;
					player1.addHero(player12);
					p1CreatNum++;
					break;
				}
				else if(p1 == false && p1CreatNum == 2)
				{
					player13 = new harrypotter;
					p1 = true;
					p2 = false;
					choice = -1;
					player1.addHero(player13);
					p1CreatNum++;
					break;
				}
				else if(p2 == false && p2CreatNum == 0)
				{
					player21 = new harrypotter;
					p2 = true;
					p1 = false;
					choice = -1;
					player2.addHero(player21);
					p2CreatNum++;
					break;
				}
				else if(p2 == false && p2CreatNum == 1)
				{
					player22 = new harrypotter;
					p2 = true;
					p1 = false;
					choice = -1;
					player2.addHero(player22);
					p2CreatNum++;
					break;
				}
				else if(p2 == false && p2CreatNum == 2)
				{
					player23 = new harrypotter;
					p2 = true;
					p1 = false;
					choice = 6;
					player2.addHero(player23);
					p2CreatNum++;
					break;
				}
				break;
	
			case 4: //medusa
				if(p1 == false && p1CreatNum == 0)
				{
					player11 = new medusa;
					p1 = true;
					p2 = false;
					choice = -1;
					player1.addHero(player11);
					p1CreatNum++;
					break;
				}
				else if(p1 == false && p1CreatNum == 1)
				{
					player12 = new medusa;
					p1 = true;
					p2 = false;
					choice = -1;
					player1.addHero(player12);
					p1CreatNum++;
					break;
				}
				else if(p1 == false && p1CreatNum == 2)
				{
					player13 = new medusa;
					p1 = true;
					p2 = false;
					choice = -1;
					player1.addHero(player13);
					p1CreatNum++;
					break;
				}
				else if(p2 == false && p2CreatNum == 0)
				{
					player21 = new medusa;
					p2 = true;
					p1 = false;
					choice = -1;
					player2.addHero(player21);
					p2CreatNum++;
					break;
				}
				else if(p2 == false && p2CreatNum == 1)
				{
					player22 = new medusa;
					p2 = true;
					p1 = false;
					choice = -1;
					player2.addHero(player22);
					p2CreatNum++;
					break;
				}
				else if(p2 == false && p2CreatNum == 2)
				{
					player23 = new medusa;
					p2 = true;
					p1 = false;
					choice = 6;
					player2.addHero(player23);
					p2CreatNum++;
					break;
				}
				break;


			case 5: //vampire
				if(p1 == false && p1CreatNum == 0)
				{
					player11 = new vampire;
					p1 = true;
					p2 = false;
					choice = -1;
					player1.addHero(player11);
					p1CreatNum++;
					break;
				}
				else if(p1 == false && p1CreatNum == 1)
				{
					player12 = new vampire;
					p1 = true;
					p2 = false;
					choice = -1;
					player1.addHero(player12);
					p1CreatNum++;
					break;
				}
				else if(p1 == false && p1CreatNum == 2)
				{
					player13 = new vampire;
					p1 = true;
					p2 = false;
					choice = -1;
					player1.addHero(player13);
					p1CreatNum++;
					break;
				}
				else if(p2 == false && p2CreatNum == 0)
				{
					player21 = new vampire;
					p2 = true;
					p1 = false;
					choice = -1;
					player2.addHero(player21);
					p2CreatNum++;
					break;
				}
				else if(p2 == false && p2CreatNum == 1)
				{
					player22 = new vampire;
					p2 = true;
					p1 = false;
					choice = -1;
					player2.addHero(player22);
					p2CreatNum++;
					break;
				}
				else if(p2 == false && p2CreatNum == 2)
				{
					player23 = new vampire;
					p2 = true;
					p1 = false;
					choice = 6;
					player2.addHero(player23);
					p2CreatNum++;
					break;
				}
				break;

			case 6:
				break;
		}
	}
	battleground(player1, player2);
}
