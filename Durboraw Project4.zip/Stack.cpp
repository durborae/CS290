/*************************************************************************
 * Name: Eric Durboraw
 * Date: 2/15/2017
 * File: Stack.cpp
 * Description: This file will implement the Stack class and will have
 * functions to add and remove nodes from the beginning and end of
 * the linked list
 * ***********************************************************************/

#include "Stack.hpp"
#include <iostream>
#include "creature.hpp"
#include <cstdlib>

using std::cin;
using std::cout;
using std::endl;

/**************************************************************************
 * Function: Stack::Stack()
 * Description: This is the constructor for the Stack class
 * ***********************************************************************/

Stack::Stack()
{
	head = NULL;
}

/**************************************************************************
 * Function: Stack::addEnd(double number)
 * Description: This function will add an element to the end of the list
 * ***********************************************************************/

void Stack::addTail(creature* creat)
{
	if(head == NULL)
	{
		head = new ListNode(creat);
		tail = head;
	}
	else
	{
		ListNode *nodePtr = head;
		while(nodePtr->next != NULL)
		{
			nodePtr = nodePtr->next;
		}
		nodePtr->next = new ListNode(creat);
		tail = nodePtr->next;//setting the tail ptr
	}
}

/**************************************************************************
 * Function: Stack::addFront(double number)
 * Description: This function will add an element to the front of the list
 * ***********************************************************************/

void Stack::addFront(creature* creat)
{
	if(head == NULL)
	{
		head = new ListNode(creat);
	}
	else
	{
		ListNode *headPtr = head;
		head = new ListNode(creat);
		head->next = headPtr;
	}
}

/**************************************************************************
 * Function: Stack:removeFront()
 * Description: This function will set the head value to the next value
 * effectively deleting the first value
 * ***********************************************************************/

void Stack::removeFront()
{
	
	ListNode* garbage;
	ListNode* newHead;
	if(head == NULL)
	{
		cout << "List is empty" << endl;
	}
	else
	{
		garbage = head;
		newHead=head->next;
		delete garbage;
		head = newHead;
	}
}

/**************************************************************************
 * Function: Stack::removeEnd()
 * Description: This will parse the linked list using two pointers one for
 * the next value, the other for the next-next value.  Once the determined
 * the next-next value is null, the next value will be likewise set to 
 * null
 * ***********************************************************************/

void Stack::removeTail()
{
	ListNode* curVal;
	ListNode* nextVal;
	if(head == NULL)
	{
		cout << "List is empty" << endl;
	}
	else if(head->next == NULL)
	{
		head = NULL;
	}
	else
	{
		curVal = head;
		nextVal = head->next;
		while(nextVal->next != NULL)
		{
			curVal = nextVal;
			nextVal = nextVal->next;
		}
		//delete nextVal;
		curVal->next = NULL;
		tail = curVal;
		//delete nextVal;
	}
}

/**************************************************************************
 * Function: Stack::printHead()
 * Description: This will print the head value
 * ***********************************************************************/

void Stack::printHead()
{
	if(head == NULL)
	{
		cout << "List is Empty." << endl;
	}
	else
	{
		cout << head->value->getType() << endl;
	}
}

/**************************************************************************
 * Function: Stack::printEnd()
 * Description: This will print the end value
 * ***********************************************************************/

void Stack::printTail()
{
	if(head == NULL)
	{
		cout << "List is empty" << endl;
	}
	else
	{
		cout << tail->value->getType() << endl;
	}
}

/**************************************************************************
 * Function: Stack::printList()
 * Description: This will print the linked list
 * ***********************************************************************/

void Stack::displayList()
{
	ListNode *printPtr = head;	
	if(head == NULL)
	{
		cout << "List is empty" << endl;
	}
	else
	{
		while(printPtr != NULL)
		{
			cout << printPtr->value->getType() << endl;
			printPtr = printPtr->next;
		}
	}
	delete printPtr;
}

/**************************************************************************
 * Function: Stack::~Stack()
 * Description: This is the destructor.
 * ***********************************************************************/

Stack::~Stack()
{
}

bool Stack::Empty()
{
	bool MT;
	
	if(head == NULL)
	{
		MT = true;
	}
	else if(head != NULL)
	{
		MT = false;
	}
	
	return MT;
}
 
