/********************************************************************
 * Name: Eric Durboraw
 * Date: 2/23/2017
 * File: Queue.cpp
 * Description: This file will implement the Queue class. It will have 
 * functions to add an item to the end of the queue, get the front 
 * value and remove the front value.
 * *****************************************************************/

#include "Queue.hpp"
#include <iostream>
#include <cstdlib>
#include "creature.hpp"

using std::cin;
using std::cout;
using std::endl;

/*******************************************************************
 * Function: Queue::Queue()
 * Description: This is the Constructor for the Queue Class
 * ****************************************************************/

Queue::Queue()
{	
	head = NULL;
	end = NULL;
}

/*******************************************************************
 * Function: ~Queue::Queue()
 * Description: This is the Destructor for the Queue Class
 * ****************************************************************/

Queue::~Queue()
{
}

/*******************************************************************
 * Function: Queue::addBack()
 * Description: This function adds an item to the end of the Queue
 * ****************************************************************/

void Queue::addBack(creature* uin)
	{
	//cout << uin->getType() << endl;
	QueueNode* current = head;
	QueueNode* nxtInLine;
	QueueNode* newNode = new QueueNode(uin);
	if(head==NULL)
	{	
		head = newNode;
		end = head;
		head->prev = end;
		head->next = end;
		end->prev = head;
		end->next = head;
	}
	else if(head != NULL)//have to figure out a better way to do this
	{
		if(end->next != NULL && end->next != head)
		{
			current = end->next;//set current to the empty val after end
			if(current->value->getType() == "Creature")//if sentinel value = -1
			{		
				nxtInLine = current->next;//set nxtInLine to the node after end
				current->value = uin;//set current to num
				delete newNode;//get rid of newNode, no longer needed
				current->next = nxtInLine; //link current to nxtInLine
				current->prev = end; //link current to end
				end = current; //move end to current
			}
		}
		if(end->next == head)
		{
			current = new QueueNode(uin);
			end->next = current;
			current->prev = end;
			current->next = head;
			end = current;
		}
	}
	current = NULL;
	delete current;
	nxtInLine = NULL;
	delete nxtInLine;
}

/******************************************************************
 * Function: Queue::getFront()
 * Description: This function returns the front value of the queue
 * ***************************************************************/

creature* Queue::getFront()
{
	creature* retCreature;	
	if(head != NULL)
	{
		retCreature = head->value;
		return retCreature;
	}
	else
	{
		retCreature = new creature;
	}
	return retCreature;
}

/*****************************************************************
 * Function: Queue::removeFront()
 * Description: This function sets the front value to -1 and the
 * head value to the next-value
 * **************************************************************/

void Queue::removeFront()
{
	creature* defaultCreature = new creature;
	head->value = defaultCreature;
	head = head->next;
}

/****************************************************************
 * Function: Queue::printQueue()
 * Description: This function will print the contents of Queue
 * *************************************************************/

void Queue::printQueue()
{	
	QueueNode* current = head;
	//string returno;
	if(current->value->getType() != "Creature")
	{
		cout << current->value->getType() << endl;
	}
	current=current->next;
	while(current != head)
	{
		if(current->value->getType() != "Creature")
		{
			cout << current->value->getType() << endl;
		}
		current=current->next;
	}
	current = NULL;
	delete current;	
}
