/**************************************************************************
 * Name: Eric Durboraw
 * Date: 2/12/2017
 * File: medusa.cpp
 * Description: This file will implement the medusa class.  It will have 
 * functions to attack, defend, get and set strength points and resolve
 * damage. If she crits, it will set the attack damage to more than enough
 * to kill any creature aside from pre-first-death Harry Potter.
 * ************************************************************************/

#include "creature.hpp"
#include "medusa.hpp"
#include <iostream>
#include <cmath>
#include <ctime>
#include <cstdlib>
#include <string>

using std::cin;
using std::cout;
using std::endl;
using std::string;

/**************************************************************************
 * Function: medusa::medusa()
 * Description: This will create a medusa creature and assign values for
 * strength points, armor, attack and defense die and define the functions
 * set as "virtual" by the base class
 * ***********************************************************************/

medusa::medusa()
{
	totalLife = 8;
	type = "Medusa";
	numDie = 2;
	armor = 3;
	attackDie = 6;
	defenseDie = 6;
	sPoints = 8;
	dDie = 1;
	cout << "Our competitor, the medusa, hails from Greece and always having a bad hair day" << endl;
}

/**************************************************************************
 * Function: medusa::attack();
 * Description: This function will generate 2 numbers 1-6 to simulate two 
 * d6 rolls
 * ***********************************************************************/

int medusa::attack()
{
	int attackRoll;
	int totalRoll = 0;
	for(int counter = 0; counter < numDie; counter++)
	{
		attackRoll = rand() % attackDie + 1;
		totalRoll += attackRoll;
	}
	if(totalRoll == 12)
	{
		totalRoll = 12345;
	}
	return totalRoll;
}

/**************************************************************************
 * Function: medusa::defense()
 * Description: This function will generate 2 random numbers 1-6 to simulate
 * 2 d6 rolls.  It will return the sum of those two rolls
 * ***********************************************************************/

int medusa::defense()
{
	int defenseRoll;
	int DRoll = 0;
	for(int counter = 0; counter < dDie; counter++)
	{			
		defenseRoll = rand() % defenseDie + 1;
		DRoll += defenseRoll;
	}
	return DRoll;
}

/**************************************************************************
 * Function: medusa::getSPoints()
 * Description: This function will return the sPoints
 * ***********************************************************************/

int medusa::getSPoints()
{
	return sPoints;
}

/**************************************************************************
 * Function: medusa::setSPoints()
 * Description: This function will allow the setting the sPoints
 * ***********************************************************************/

void medusa::setSPoints(int sIn)
{
	sPoints = sIn;
}

/**************************************************************************
 * Function: medusa::takeDamage(int)
 * Description: This function will receive a damage parameter and call the
 * defense function and determine damage resolutionl. 
 * ***********************************************************************/

void medusa::takeDamage(int oppDamage)
{
	int dRoll = this->defense();
	cout << "Medusa Defends for: " << dRoll << endl;
	int endDam;

	endDam = oppDamage - dRoll - armor;
	if(endDam > 0)
	{
		dRoll = sPoints - endDam;
		this->setSPoints(dRoll);
	}
}

string medusa::getType()
{
	return type;
}
