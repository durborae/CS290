/*************************************************************************
 * Name: Eric Durboraw
 * Date: 2/12/2017
 * File: harrypotter.cpp
 * Description: This file will implement the harrypotter class.  
 * It will have functions to attack, defend, get and set strength points 
 * and resolve damage.
 * ***********************************************************************/

#include "creature.hpp"
#include "harrypotter.hpp"
#include <iostream>
#include <cmath>
#include <ctime>
#include <cstdlib>
#include <string>

using std::cin;
using std::cout;
using std::endl;
using std::string;

/**************************************************************************
 * Function: harrypotter::harrypotter()
 * Description: This will create a harrypotter creature and assign values 
 * for strength points, armor, attack and defense die and define the 
 * functions set as "virtual" by the base class
 * ***********************************************************************/

harrypotter::harrypotter()
{
	totalLife = 10;
	type = "Harry Potter";
	numDie = 2;
	armor = 0;
	attackDie = 6;
	defenseDie = 6;
	sPoints = 10;
	dDie = 2;
	phoenix = false;
	cout << "Our competitor, Harry Potter, is the Seeker for the Gryffindor House!" << endl;
}

/**************************************************************************
 * Function: harrypotter::attack();
 * Description: This function will generate 2 numbers 1-6 to simulate two 
 * d6 rolls
 * ***********************************************************************/

int harrypotter::attack()
{
	int attackRoll;
	int totalRoll = 0;
	for(int counter = 0; counter < numDie; counter++)
	{
		attackRoll = rand() % attackDie + 1;
		totalRoll += attackRoll;
	}
	return totalRoll;
}

/**************************************************************************
 * Function: harrypotter::defense()
 * Description: This function will generate 2 random numbers 1-6 to simulate
 * 2 d6 rolls.  It will return the sum of those two rolls
 * ***********************************************************************/

int harrypotter::defense()
{
	int defenseRoll;
	int DRoll = 0;
	for(int counter = 0; counter < dDie; counter++)
	{			
		defenseRoll = rand() % defenseDie + 1;
		DRoll += defenseRoll;
	}
	return DRoll;
}

/**************************************************************************
 * Function: harrypotter::getSPoints()
 * Description: This function will return the sPoints
 * ***********************************************************************/

int harrypotter::getSPoints()
{
	return sPoints;
}

/**************************************************************************
 * Function: harrypotter::setSPoints()
 * Description: This function will allow the setting the sPoints
 * ***********************************************************************/

void harrypotter::setSPoints(int sIn)
{
	sPoints = sIn;
}

/**************************************************************************
 * Function: harrypotter::takeDamage(int)
 * Description: This function will receive a damage parameter and call the
 * defense function and determine damage resolutionl. 
 * ***********************************************************************/

void harrypotter::takeDamage(int oppDamage)
{
	int dRoll = this->defense();
	cout << "Harry Potter, Boy Wizard, Defends for: " << dRoll << endl;
	int endDam;

	endDam = oppDamage - dRoll - armor;
	if(endDam > 0)
	{
		dRoll = sPoints - endDam;
		this->setSPoints(dRoll);
	}
	this->phoenixRising();
}

/**************************************************************************
 * Function: harrypotter::phoenixRising()
 * Description: This function will trigger if Harry has died, reset his
 * life if he has died and the phoenix variable is false
 * ***********************************************************************/

void harrypotter::phoenixRising()
{
	if(sPoints <= 0 && phoenix == false)
	{
		cout << "From the ashes rises the Boy Wizard!" << endl;
		sPoints = 20;
		totalLife = 20;
		phoenix = true;
	}
	else if(sPoints <=0 && phoenix == true)
	{
		cout << "Harry has died! Muggles and wizards alike mourn this loss." << endl;
	}
}

string harrypotter::getType()
{
	return type;
}
