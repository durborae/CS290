/*************************************************************************
 * Name: Eric Durboraw
 * Date: 2/9/2017
 * File: Menu.hpp
 * Description: This will define the menu function that will set up user
 * options for list
 * ***********************************************************************/

#ifndef MENU_HPP
#define MENU_HPP

#include <iostream>
#include <string>
#include "creature.hpp"
#include "barbarian.hpp"
#include "vampire.hpp"
#include "harrypotter.hpp"
#include "medusa.hpp"
#include "bluemen.hpp"
#include <cstdlib>
#include <ctime>

void menu();

#endif
