/*************************************************************************
 * Name: Eric Durboraw
 * Date: 2/12/2017
 * File: barbarian.cpp
 * Description: This file will implement the barbarian class.  It will have
 * functions to attack, defend, get and set strength points and resolve
 * damage.
 * ***********************************************************************/

#include "creature.hpp"
#include "barbarian.hpp"
#include <iostream>
#include <cmath>
#include <ctime>
#include <cstdlib>

using std::cin;
using std::cout;
using std::endl;

/**************************************************************************
 * Function: barbarian::barbarian()
 * Description: This will create a vampire creature and assign values for
 * strength points, armor, attack and defense die and define the functions
 * set as "virtual" by the base class
 * ***********************************************************************/

barbarian::barbarian()
{
	totalLife = 12;
	type = "Barbarian";
	numDie = 2;
	armor = 0;
	attackDie = 6;
	defenseDie = 6;
	sPoints = 12;
	dDie = 2;
	cout << "Our competitor, the Barbarian, hails from Austria and mumbles something about getting to the chopper." << endl;
}

/**************************************************************************
 * Function: barbarian::attack();
 * Description: This function will generate 2 numbers 1-6 to simulate two 
 * d6 rolls
 * ***********************************************************************/

int barbarian::attack()
{
	//srand(time(0));
	int attackRoll;
	int totalRoll = 0;
	for(int counter = 0; counter < numDie; counter++)
	{
		attackRoll = rand() % attackDie + 1;
		totalRoll += attackRoll;
	}
	return totalRoll;
}

/**************************************************************************
 * Function: barbarian::defense()
 * Description: This function will generate 2 random numbers 1-6 to simulate
 * 2 d6 rolls.  It will return the sum of those two rolls
 * ***********************************************************************/

int barbarian::defense()
{
	//srand(time(0));
	int defenseRoll;
	int DRoll = 0;
	for(int counter = 0; counter < dDie; counter++)
	{			
		defenseRoll = rand() % defenseDie + 1;
		DRoll += defenseRoll;
	}
	return DRoll;
}

/**************************************************************************
 * Function: barbarian::getSPoints()
 * Description: This function will return the sPoints
 * ***********************************************************************/

int barbarian::getSPoints()
{
	return sPoints;
}

/**************************************************************************
 * Function: barbarian::setSPoints()
 * Description: This function will allow the setting the sPoints
 * ***********************************************************************/

void barbarian::setSPoints(int sIn)
{
	sPoints = sIn;
}

/**************************************************************************
 * Function: barbarian::takeDamage(int)
 * Description: This function will receive a damage parameter and call the
 * defense function and determine damage resolutionl. 
 * ***********************************************************************/

void barbarian::takeDamage(int oppDamage)
{
	int dRoll = this->defense();
	cout << "Barbarian Defends for: " << dRoll << endl;
	int endDam;

	endDam = oppDamage - dRoll - armor;
	if(endDam > 0)
	{
		dRoll = sPoints - endDam;
		this->setSPoints(dRoll);
	}
}


string barbarian::getType()
{
	return type;
}
