/**************************************************************************
 * Name: Eric Durboraw
 * Date: 2/14/2017
 * File: battleground.hpp
 * Description: This is the battleground function where the combat will 
 * take place between two characters
 * ************************************************************************/

#ifndef BATTLEGROUND_HPP
#define BATTLEGROUND_HPP

#include <iostream>
#include <string>
#include "creature.hpp"
#include "barbarian.hpp"
#include "vampire.hpp"
#include "harrypotter.hpp"
#include "medusa.hpp"
#include "bluemen.hpp"
#include <cstdlib>
#include <ctime>
#include "Stack.hpp"
#include "Queue.hpp"
#include "heroStack.hpp"

void battleground(heroStack player1, heroStack player2);

#endif
