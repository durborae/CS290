/**************************************************************************
 * Name: Eric Durboraw
 * Date: 2/11/2017
 * File: creature.hpp
 * Description: This is the header for the creature class. It will contain
 * virtual functions for attacking and defending, and functions for sp
 * changes
 * ***********************************************************************/

#ifndef CREATURE_HPP
#define CREATURE_HPP

#include <iostream>
#include <cmath>
#include <string>
using std::string;

class creature
{
	private:
		int sPoints;
		int armor;
		int attackDie;
		int defenseDie;
		string type;
		int totalLife;

	public:
		creature();
		virtual int attack();
		virtual int defense();
		virtual int getSPoints();
		virtual void setSPoints(int);
		virtual void takeDamage(int);
		void operator=(const creature &right);
		virtual string getType();
		void restoreLife();
};
#endif
