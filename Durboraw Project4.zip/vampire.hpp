/**************************************************************************
 * Name: Eric Durboraw
 * Date: 2/11/2017
 * File: vampire.hpp
 * Description: This file wil implement the vampire class. It will have 
 * functions to attack, defend (which could charm the opponent), get and
 * set strength points and take damage from attacks.
 * ***********************************************************************/

#ifndef VAMPIRE_HPP
#define VAMPIRE_HPP

#include "creature.hpp"
#include <iostream>
#include <cmath>
#include <ctime>
#include <cstdlib>
#include <string>

using std::cin;
using std::cout;
using std::endl;
using std::string;

class vampire: public creature
{
	private:
		int sPoints;
		int armor;
		int attackDie;
		int defenseDie;
		int numDie;
		//srand ((unsigned)time(0));
		bool charmed;
		string type;
		int totalLife;

	public:
		vampire();
		int attack();
		int defense();
		int getSPoints();
		void setSPoints(int);
		void takeDamage(int);
		string getType();
};
#endif
