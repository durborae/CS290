/**************************************************************************
 * Name: Eric Durboraw
 * Date: 2/14/2017
 * File: battleground.cpp
 * Description: This will implement the battleground function.
 * ***********************************************************************/

#include <iostream>
#include <string>
#include "creature.hpp"
#include "barbarian.hpp"
#include "vampire.hpp"
#include "harrypotter.hpp"
#include "medusa.hpp"
#include "bluemen.hpp"
#include <cstdlib>
#include <ctime>
#include "Queue.hpp"
#include "Stack.hpp"
#include "heroStack.hpp"

using std::cin;
using std::cout;
using std::endl;

void battleground(heroStack hStack1, heroStack hStack2)
{
	int p1CharRemaining = 3;
	int p2CharRemaining = 3;
	creature* player1;
	creature* player2;
	int matchNum = 1;
	int p1Score = 0;
	int p2Score = 0;
	while(p1CharRemaining > 0 && p2CharRemaining > 0)
	{
		player1 = hStack1.currentCreature();
		player2 = hStack2.currentCreature();
		int p1Life = player1->getSPoints();
		int p2Life = player2->getSPoints();
		int getvalues;

		while(p1Life > 0 && p2Life > 0)
		{
				//player 1 attack
			getvalues = player1->attack();
			cout << player1->getType() << " did: " << getvalues << " Damange." << endl;
			player2->takeDamage(getvalues);
			p2Life = player2->getSPoints();
			cout << player2->getType() << " has " << p2Life << " life remaining." << endl;
			cout << endl;

			if(p2Life <= 0)
			{
				cout << player1->getType() << " beat " << player2->getType() << endl;
				cout << "Player 1 has won match #" << matchNum << endl;
				hStack1.winner();
				hStack2.death();
				matchNum++;
				p1Score++;
				p2CharRemaining--;
				cout << "Score: Player 1- " << p1Score << " Player 2- " << p2Score << endl;
				break;
			}
			//player 2 attack
			getvalues = player2->attack();
			cout << player2->getType() << " did: " << getvalues << " Damange." << endl;
			player1->takeDamage(getvalues);
			p1Life = player1->getSPoints();
			cout << player1->getType() << " has " << p1Life << " life remaining." << endl;
			cout << endl;
			if(p1Life <= 0)
			{
				cout << player2->getType() << " beat " << player1->getType() <<endl;
				cout << "Player 2 has won match#" << matchNum << endl;
				hStack1.death();
				hStack2.winner();
				matchNum++;
				p2Score++;
				p1CharRemaining--;
				cout << "Score: Player 1- " << p1Score << " Player 2- " << p2Score << endl;
				break;
			}
		}
	}
}
