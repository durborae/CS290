/*************************************************************************
 * Name: Eric Durboraw
 * Date: 2/27/2017
 * File: heroStack.hpp
 * Description: This will create the herostack class.  It will have two
 * stack objects an alive queue and a dead stack.  It will have a death 
 * function, and a print stack/queue function.  It will also have a 
 * function to return the top character from the alive queue
 * **********************************************************************/ 

#ifndef HEROSTACK_HPP
#define HEROSTACK_HPP
#include <iostream>
#include <cstdlib>
#include "creature.hpp"
#include "Queue.hpp"
#include "Stack.hpp"

class heroStack
{
	private:
		int aliveNum;
		int deadNum;
		Queue alive;
		Stack dead;
		
	public:
		heroStack();
		~heroStack();
		creature getAliveFront();
		void death();
		void printDead();
		void addHero(creature*);
		creature* currentCreature();
		void winner();
};
#endif
