/**************************************************************************
 * Name: Eric Durboraw
 * Date: 2/12/2017
 * File: bluemen.hpp
 * Description: This is the headerfile for the bluemen character. They will
 * have the ability to attack, defend, get and set strength points and
 * resolve attack damage.  It will also have a function to determine if it
 * should reduce the number of defense die based on health
 * ***********************************************************************/

#ifndef BLUEMEN_HPP
#define BLUEMEN_HPP

#include "creature.hpp"
#include <iostream>
#include <cmath>
#include <ctime>
#include <cstdlib>
#include <string>

using std::cin;
using std::cout;
using std::endl;
using std::string;

class bluemen: public creature
{
	private:
		int sPoints;
		int armor;
		int attackDie;
		int defenseDie;
		int numDie;
		int dDie;
		string type;
		int totalLife;

	public:
		bluemen();
		int attack();
		int defense();
		int getSPoints();
		void setSPoints(int);
		void takeDamage(int);
		void checkDDie();
		string getType();
};
#endif


