/*************************************************************************
 * Name: Eric Durboraw
 * Date: 2/12/2017
 * File: harrypotter.hpp
 * Description: This is the header for the harrypotter class.  It will have 
 * functions to attack, defend, get and set strength points and take 
 * damage.
 * ***********************************************************************/

#ifndef HARRYPOTTER_HPP
#define HARRYPOTTER_HPP

#include "creature.hpp"
#include <iostream>
#include <cmath>
#include <ctime>
#include <cstdlib>
#include <string>

using std::cin;
using std::cout;
using std::endl;
using std::string;


class harrypotter: public creature
{
	private:
		int sPoints;
		int armor;
		int attackDie;
		int defenseDie;
		int numDie;
		int dDie;
		bool phoenix;
		string type;
		int totalLife;

	public:
		harrypotter();
		int attack();
		int defense();
		int getSPoints();
		void setSPoints(int);
		void takeDamage(int);
		void phoenixRising();
		string getType();
};
#endif


