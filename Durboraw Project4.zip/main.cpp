/**************************************************************************
 * Name: Eric Durboraw
 * Date: 2/14/2017
 * File: main.cpp
 * Description: This is the main method that will call the menu and 
 * battlefield functions
 * ***********************************************************************/

#include <iostream>
#include <string>
#include "creature.hpp"
#include "barbarian.hpp"
#include "vampire.hpp"
#include "harrypotter.hpp"
#include "medusa.hpp"
#include "bluemen.hpp"
#include "menu.hpp"
#include <cstdlib>
#include <ctime>
#include "Queue.hpp"
#include "Stack.hpp"
#include "heroStack.hpp"

int main()
{
	//creature* player1;
	//creature* player2;
	srand(time(0));

	menu();

return 0;
}
