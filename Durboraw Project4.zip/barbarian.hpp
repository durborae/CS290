/*************************************************************************
 * Name: Eric Durboraw
 * Date: 2/12/2017
 * File: barbarian.hpp
 * Description: This is the header for the Barbarian class.  It will have 
 * functions to attack, defend, get and set strength points and take 
 * damage.
 * ***********************************************************************/

#ifndef BARBARIAN_HPP
#define BARBARIAN_HPP

#include "creature.hpp"
#include <iostream>
#include <cmath>
#include <ctime>
#include <cstdlib>
#include <string>

using std::cin;
using std::cout;
using std::endl;
using std::string;

class barbarian: public creature
{
		private:
			int sPoints;
			int armor;
			int attackDie;
			int defenseDie;
			int numDie;
			int dDie;
			int totalLife;
			string type;

		public:
			barbarian();
			int attack();
			int defense();
			int getSPoints();
			void setSPoints(int);
			void takeDamage(int);
			string getType();
};
#endif

