/************************************************************************
 * Name: Eric Durboraw
 * Date: 2/23/2017
 * File: Queue.hpp
 * Description: This is the header file for the Queue class. It will have
 * functions to add a item to the end of the queue, get the first value of
 * the queue, and remove the first time in the structure. It will be 
 * circular
 * **********************************************************************/

#ifndef QUEUE_HPP
#define QUEUE_HPP

#include <iostream>
#include <cstdlib>
#include "creature.hpp"

using std::cout;
using std::endl;

class Queue
{
	protected:
		struct QueueNode
		{
			creature* value;
			QueueNode *next;
			QueueNode *prev;
			QueueNode(creature* value1, QueueNode *next1 = NULL, QueueNode *prev1 = NULL)
			{
				value = value1;
				next = next1;
				prev = prev1;
			}
		};
		QueueNode *head;
		QueueNode *end;

	public:
		Queue();
		~Queue();
		void addBack(creature* creat);
		creature* getFront();
		void removeFront();
		void printQueue();
};
#endif
